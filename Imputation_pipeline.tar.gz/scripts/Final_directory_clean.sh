rm shape*
rm input*
rm *temp*
rm plink*
mv merged.vcf.gz imputed.vcf.gz
rm *merge*
rm chr*imputed*gz
rm chr*imputed*erate
rm chr*rec
