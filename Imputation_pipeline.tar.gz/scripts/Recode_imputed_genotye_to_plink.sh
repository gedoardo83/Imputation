plink --vcf merged.vcf.gz --make-bed --out merged
