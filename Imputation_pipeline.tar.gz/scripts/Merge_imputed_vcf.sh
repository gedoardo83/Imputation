/data0/opt/bcftools/bcftools concat \
chr10.imputed.dose.vcf.gz \
chr11.imputed.dose.vcf.gz \
chr12.imputed.dose.vcf.gz \
chr13.imputed.dose.vcf.gz \
chr14.imputed.dose.vcf.gz \
chr15.imputed.dose.vcf.gz \
chr16.imputed.dose.vcf.gz \
chr17.imputed.dose.vcf.gz \
chr18.imputed.dose.vcf.gz \
chr19.imputed.dose.vcf.gz \
chr1.imputed.dose.vcf.gz \
chr20.imputed.dose.vcf.gz \
chr21.imputed.dose.vcf.gz \
chr22.imputed.dose.vcf.gz \
chr2.imputed.dose.vcf.gz \
chr3.imputed.dose.vcf.gz \
chr4.imputed.dose.vcf.gz \
chr5.imputed.dose.vcf.gz \
chr6.imputed.dose.vcf.gz \
chr7.imputed.dose.vcf.gz \
chr8.imputed.dose.vcf.gz \
chr9.imputed.dose.vcf.gz \
| gzip -c >  merged.vcf.gz
